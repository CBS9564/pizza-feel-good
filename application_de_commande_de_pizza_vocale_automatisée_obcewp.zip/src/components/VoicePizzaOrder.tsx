import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Terminal, PhoneCall, PhoneOff, Mic, MicOff, Pizza, Utensils } from "lucide-react"; // Replaced Burger with Utensils

interface MenuItem {
  name: string;
  sizes: { [key: string]: number };
  toppings: string[];
}

interface Menu {
  pizzas: MenuItem[];
  burgers: MenuItem[];
  salads: MenuItem[]; // Added salads
  lasagna: MenuItem[]; // Added lasagna
  desserts: MenuItem[]; // Added desserts
}

interface OrderItem {
  name: string;
  type: 'pizza' | 'burger' | 'salad' | 'lasagna' | 'dessert'; // Added types
  size: string;
  quantity: number;
  specialInstructions?: string;
  price: number;
}

interface Order {
  id: string;
  customerName: string;
  items: OrderItem[];
  total: number;
  timestamp: string;
}

// Load menu data from JSON file (simulated)
// In a real app, you'd fetch this. Here we hardcode for simplicity in WebContainer.
const menu: Menu = {
  "pizzas": [
    {
      "name": "Margarita",
      "sizes": {
        "unique": 10.50
      },
      "toppings": ["mozzarella", "olives", "origan", "base tomate"]
    },
    {
      "name": "Reine",
      "sizes": {
        "unique": 13.00
      },
      "toppings": ["mozzarella", "jambon blanc", "champignons", "olives", "base tomate"]
    },
    {
      "name": "4 fromages",
      "sizes": {
        "unique": 14.50
      },
      "toppings": ["mozzarella", "roquefort", "bleu", "chèvre", "origan", "base tomate"]
    },
    {
      "name": "Chèvre miel",
      "sizes": {
        "unique": 13.50
      },
      "toppings": ["mozzarella", "chèvre", "miel", "origan", "base tomate"]
    },
    {
      "name": "Chorizo",
      "sizes": {
        "unique": 13.50
      },
      "toppings": ["mozzarella", "chorizo", "poivrons", "olives", "origan", "base tomate"]
    },
    {
      "name": "Landaise",
      "sizes": {
        "unique": 14.00
      },
      "toppings": ["mozzarella", "magret de canard", "poivrons", "olives", "origan", "base tomate"]
    },
    {
      "name": "Baba",
      "sizes": {
        "unique": 14.00
      },
      "toppings": ["mozzarella", "jambon de Bayonne", "poivrons", "guindillas", "olives", "origan", "base tomate"]
    },
    {
      "name": "Euskadi",
      "sizes": {
        "unique": 14.50
      },
      "toppings": ["mozzarella", "boeuf haché", "poivrons", "piment", "tomates confites", "olives", "base tomate"]
    },
    {
      "name": "Burrata",
      "sizes": {
        "unique": 16.00
      },
      "toppings": ["mozzarella", "merguez", "pignons de pin", "pestou", "burrata", "olives", "origan", "base tomate"]
    },
    {
      "name": "Serrano",
      "sizes": {
        "unique": 16.00
      },
      "toppings": ["mozzarella", "serrano", "tomates confites", "burrata", "pesto", "origan", "olives", "base tomate"]
    },
    {
      "name": "Raclette",
      "sizes": {
        "unique": 14.50
      },
      "toppings": ["mozzarella", "raclette", "lardons", "œuf", "pomme de terre grenailles", "origan", "base crème"]
    },
    {
      "name": "Calzone",
      "sizes": {
        "unique": 13.50
      },
      "toppings": ["mozzarella", "jambon blanc", "champignons", "oeuf", "origan", "base tomate"]
    },
    {
      "name": "Carnivore",
      "sizes": {
        "unique": 16.00
      },
      "toppings": ["mozzarella", "lardons", "boeuf haché", "chorizo", "magret de canard", "jambon de bayonne", "olives", "origan", "base tomate"]
    },
    {
      "name": "Veggie",
      "sizes": {
        "unique": 14.50
      },
      "toppings": ["mozzarella", "champignons", "poivrons", "roquette", "tomates confites", "olives", "origan", "base tomate"]
    },
    {
      "name": "Saumon",
      "sizes": {
        "unique": 15.00
      },
      "toppings": ["mozzarella", "saumon", "câpres", "ciboulette", "crème fraiche", "origan", "base crème"]
    },
    {
      "name": "Anchois",
      "sizes": {
        "unique": 13.50
      },
      "toppings": ["mozzarella", "anchois", "câpres", "olives", "origan", "base tomate"]
    }
  ],
  "burgers": [
    {
      "name": "Le cheese",
      "sizes": {
        "unique": 13.00
      },
      "toppings": ["steak", "cheddar", "tomates confites", "oignons", "sauce maison"]
    },
    {
      "name": "Bartholome",
      "sizes": {
        "unique": 15.00
      },
      "toppings": ["steak", "raclette", "poitrine de porc", "oignons", "sauce barbecue"]
    },
    {
      "name": "Big ky",
      "sizes": {
        "unique": 14.00
      },
      "toppings": ["steak", "tomme de savoie", "tomates confites", "sauce maison"]
    },
    {
      "name": "Baskibuzz",
      "sizes": {
        "unique": 14.00
      },
      "toppings": ["steak", "ardi gasna", "piquillos", "piments", "sauce maison"]
    },
    {
      "name": "Pollo loco",
      "sizes": {
        "unique": 13.50
      },
      "toppings": ["poulet", "cheddar", "poivrons", "estragon", "sauce maison"]
    },
    {
      "name": "Vege",
      "sizes": {
        "unique": 13.00
      },
      "toppings": ["mozzarella", "oignons", "poivrons", "tomates confites", "pomme de terre", "roquette", "sauce maison"]
    },
    {
      "name": "Poupy",
      "sizes": {
        "unique": 15.00
      },
      "toppings": ["steak", "chèvre", "jambon de bayonne", "miel", "sauce maison"]
    }
  ],
  "salads": [
    {
      "name": "Salade baraski",
      "sizes": {
        "unique": 13.50
      },
      "toppings": ["roquette", "artichauts", "courgette", "aubergines", "olives", "pignons de pins", "tomates confites", "tomates cerises", "burrata", "pesto", "ciboulette", "grissini"]
    },
    {
      "name": "Salade bidartar",
      "sizes": {
        "unique": 15.00
      },
      "toppings": ["roquette", "chèvre", "burrata", "magret de canard", "jambon de Bayonne", "chorizo", "tomates confites", "pesto", "ciboulette", "grissini"]
    }
  ],
  "lasagna": [
    {
      "name": "Lasagnes maison",
      "sizes": {
        "unique": 14.00
      },
      "toppings": ["bœuf haché", "sauce tomate", "pecorino", "roquette", "tomates"]
    }
  ],
  "desserts": [
    {
      "name": "Tiramisu",
      "sizes": {
        "unique": 4.50
      },
      "toppings": []
    },
    {
      "name": "Panna cotta",
      "sizes": {
        "unique": 4.50
      },
      "toppings": []
    },
    {
      "name": "Cheesecake",
      "sizes": {
        "unique": 4.50
      },
      "toppings": []
    },
    {
      "name": "Mousse chocolat",
      "sizes": {
        "unique": 4.50
      },
      "toppings": []
    }
  ]
};


const SPEECH_LANG = 'fr-FR';

const VoicePizzaOrder: React.FC = () => {
  const [callState, setCallState] = useState<'idle' | 'connecting' | 'in-call' | 'ordering' | 'confirming' | 'ended'>('idle');
  const [transcript, setTranscript] = useState<string>('');
  const [conversation, setConversation] = useState<string[]>([]);
  const [currentOrder, setCurrentOrder] = useState<OrderItem[]>([]);
  const [customerName, setCustomerName] = useState<string>('');
  const [smsStatus, setSmsStatus] = useState<string | null>(null);

  const recognitionRef = useRef<SpeechRecognition | null>(null);
  const synthRef = useRef<SpeechSynthesis | null>(null);
  const isSpeakingRef = useRef<boolean>(false);

  useEffect(() => {
    // Initialize Speech Synthesis
    synthRef.current = window.speechSynthesis;

    // Initialize Speech Recognition
    if ('SpeechRecognition' in window || 'webkitSpeechRecognition' in window) {
      const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      recognitionRef.current = new SpeechRecognition();
      recognitionRef.current.continuous = false; // Listen for a single phrase
      recognitionRef.current.interimResults = false; // Only return final results
      recognitionRef.current.lang = SPEECH_LANG;

      recognitionRef.current.onresult = (event: SpeechRecognitionEvent) => {
        const speechResult = event.results[event.results.length - 1][0].transcript;
        setTranscript(speechResult);
        addConversation('Client: ' + speechResult);
        processVoiceCommand(speechResult);
      };

      recognitionRef.current.onerror = (event: SpeechRecognitionErrorEvent) => {
        console.error('Speech recognition error:', event.error);
        if (event.error === 'no-speech') {
           // Ignore no-speech errors unless we are actively waiting for input
           if (callState === 'ordering' || callState === 'confirming') {
             speak("Désolé, je n'ai pas entendu. Pouvez-vous répéter ?");
           }
        } else if (event.error === 'not-allowed') {
           addConversation("Système: L'accès au microphone a été refusé. Veuillez l'autoriser pour utiliser la commande vocale.");
           speak("L'accès au microphone a été refusé. Veuillez l'autoriser pour utiliser la commande vocale.");
        } else {
           addConversation("Système: Une erreur de reconnaissance vocale est survenue. Veuillez réessayer.");
           speak("Une erreur de reconnaissance vocale est survenue. Veuillez réessayer.");
        }
        // Attempt to restart recognition if in a state where we expect input
        if (callState === 'ordering' || callState === 'confirming') {
             startListening();
        }
      };

      recognitionRef.current.onend = () => {
         console.log('Speech recognition ended.');
         // Restart listening if in a state where we expect input and not speaking
         if ((callState === 'ordering' || callState === 'confirming') && !isSpeakingRef.current) {
             startListening();
         }
      };

    } else {
      addConversation("Système: La reconnaissance vocale n'est pas prise en charge par votre navigateur.");
    }

    return () => {
      recognitionRef.current?.stop();
      synthRef.current?.cancel();
    };
  }, [callState]); // Re-run effect if callState changes to adjust listening behavior

  const addConversation = (message: string) => {
    setConversation(prev => [...prev, message]);
  };

  const speak = (text: string, onEndCallback?: () => void) => {
    if (!synthRef.current) {
      console.error("Speech synthesis not available.");
      addConversation("Système: La synthèse vocale n'est pas disponible.");
      onEndCallback?.();
      return;
    }

    // Stop current recognition before speaking
    recognitionRef.current?.stop();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = SPEECH_LANG;

    utterance.onstart = () => {
        isSpeakingRef.current = true;
        console.log('Speaking started:', text);
    };

    utterance.onend = () => {
        isSpeakingRef.current = false;
        console.log('Speaking ended.');
        onEndCallback?.();
        // Restart listening after speaking if in a state where we expect input
        if (callState === 'ordering' || callState === 'confirming') {
            startListening();
        }
    };

    utterance.onerror = (event) => {
        isSpeakingRef.current = false;
        console.error('Speech synthesis error:', event);
        onEndCallback?.();
         // Restart listening after speaking error if in a state where we expect input
        if (callState === 'ordering' || callState === 'confirming') {
            startListening();
        }
    };

    synthRef.current.speak(utterance);
    addConversation('Système: ' + text);
  };

  const startListening = () => {
    if (recognitionRef.current && !isSpeakingRef.current) {
       try {
         recognitionRef.current.start();
         console.log('Speech recognition started.');
       } catch (error) {
         console.warn('Recognition already started or error:', error);
         // If already started, no need to do anything. If other error, it will be caught by onerror.
       }
    } else if (isSpeakingRef.current) {
        console.log('Cannot start listening while speaking.');
    } else {
        console.error('Speech recognition not available.');
    }
  };

  const stopListening = () => {
     if (recognitionRef.current) {
        recognitionRef.current.stop();
        console.log('Speech recognition stopped.');
     }
  };

  const handleIncomingCall = () => {
    setCallState('connecting');
    setConversation([]);
    setCurrentOrder([]);
    setCustomerName('');
    setSmsStatus(null);
    addConversation('Système: Appel entrant...');
    setTimeout(() => {
      setCallState('in-call');
      speak("Bonjour et bienvenue au service de commande vocale de Pizza Bolt. Pour commencer, quel est votre nom ?");
    }, 2000); // Simulate connection time
  };

  const handleEndCall = () => {
    stopListening();
    synthRef.current?.cancel();
    setCallState('ended');
    addConversation('Système: Appel terminé.');
  };

  const processVoiceCommand = (command: string) => {
    const lowerCommand = command.toLowerCase();

    if (callState === 'in-call') {
      // Assume the first command after greeting is the name
      setCustomerName(command);
      setCallState('ordering');
      speak(`Bonjour ${command}. Que souhaitez-vous commander aujourd'hui ? Vous pouvez dire par exemple "Je voudrais une pizza Margherita", "un burger Le cheese", "une salade baraski", "les lasagnes maison" ou "un tiramisu".`);
      // Start listening automatically after speaking
    } else if (callState === 'ordering') {
      // Process order command
      const orderMatch = matchOrder(lowerCommand);

      if (orderMatch) {
        setCurrentOrder(prev => [...prev, orderMatch]);
        const orderSummary = `${orderMatch.quantity} ${orderMatch.type} ${orderMatch.name} pour ${orderMatch.price.toFixed(2)}€`;
        speak(`J'ai ajouté ${orderSummary} à votre commande. Souhaitez-vous ajouter autre chose ou confirmer votre commande ?`);
        // Start listening automatically after speaking
      } else if (lowerCommand.includes('confirmer') || lowerCommand.includes('terminer')) {
        if (currentOrder.length === 0) {
          speak("Votre panier est vide. Souhaitez-vous commander quelque chose ?");
           // Start listening automatically after speaking
        } else {
          setCallState('confirming');
          confirmOrder();
        }
      } else if (lowerCommand.includes('annuler')) {
        speak("Votre commande actuelle a été annulée. Que souhaitez-vous faire ?");
        setCurrentOrder([]);
         // Start listening automatically after speaking
      }
      else {
        speak("Désolé, je n'ai pas compris votre commande ou ce produit n'est pas disponible. Pouvez-vous répéter ou commander autre chose ?");
         // Start listening automatically after speaking
      }
    } else if (callState === 'confirming') {
        if (lowerCommand.includes('oui') || lowerCommand.includes('confirmer')) {
            finalizeOrder();
        } else if (lowerCommand.includes('non') || lowerCommand.includes('modifier')) {
            setCallState('ordering');
            speak("D'accord, nous pouvons modifier votre commande. Que souhaitez-vous ajouter ou retirer ?");
             // Start listening automatically after speaking
        } else {
            speak("Désolé, je n'ai pas compris. Voulez-vous confirmer votre commande ou la modifier ?");
             // Start listening automatically after speaking
        }
    }
  };

  const matchOrder = (command: string): OrderItem | null => {
    // Simple pattern matching for demonstration.
    // A real LLM integration would be more robust here.
    const quantityMatch = command.match(/(\d+)\s+/);
    const quantity = quantityMatch ? parseInt(quantityMatch[1], 10) : 1;

    let matchedItem: MenuItem | undefined = undefined;
    let itemType: OrderItem['type'] | undefined = undefined;
    let price = 0;

    // Define the order of checking categories
    const categories: (keyof Menu)[] = ['pizzas', 'burgers', 'salads', 'lasagna', 'desserts'];

    for (const category of categories) {
        for (const item of menu[category]) {
            // Check if the command includes the item name (case-insensitive)
            if (lowerCommand.includes(item.name.toLowerCase())) {
                matchedItem = item;
                itemType = category.slice(0, -1) as OrderItem['type']; // Convert 'pizzas' to 'pizza', 'burgers' to 'burger', etc.
                 if (category === 'lasagna') itemType = 'lasagna'; // Handle singular 'lasagna'
                 if (category === 'desserts') itemType = 'dessert'; // Handle singular 'dessert'


                const sizeKey = Object.keys(item.sizes)[0];
                if (sizeKey) {
                     price = item.sizes[sizeKey];
                } else {
                    // If no size/price is defined, skip this item
                    continue;
                }
                // Found a match, break loops
                break;
            }
        }
        if (matchedItem) break; // Break outer loop if item found
    }


    if (matchedItem && itemType) {
      const totalPrice = price * quantity;
      // Basic special instructions extraction (very naive)
      const instructionsMatch = command.match(/avec\s+(.*)/);
      const specialInstructions = instructionsMatch ? instructionsMatch[1] : undefined;

      // Assuming size is always the first key in the sizes object for this menu
      const size = Object.keys(matchedItem.sizes)[0] || 'unique'; // Default to 'unique' if somehow missing

      return {
        name: matchedItem.name,
        type: itemType,
        size: size, // Use the determined size
        quantity: quantity,
        price: totalPrice,
        specialInstructions: specialInstructions
      };
    }

    return null; // No match found
  };

  const confirmOrder = () => {
    const total = currentOrder.reduce((sum, item) => sum + item.price, 0);
    const orderSummary = currentOrder.map(item => `${item.quantity} ${item.type} ${item.name}`).join(', ');
    speak(`Votre commande actuelle est : ${orderSummary}. Le total est de ${total.toFixed(2)}€. Voulez-vous confirmer ?`);
     // Start listening automatically after speaking
  };

  const finalizeOrder = () => {
    const total = currentOrder.reduce((sum, item) => sum + item.price, 0);
    const orderId = 'ORD-' + Date.now(); // Simple unique ID
    const orderTimestamp = new Date().toISOString();

    const finalOrder: Order = {
      id: orderId,
      customerName: customerName || 'Client Anonyme',
      items: currentOrder,
      total: total,
      timestamp: orderTimestamp
    };

    // Simulate saving to localStorage
    const savedOrders = JSON.parse(localStorage.getItem('pizzaOrders') || '[]');
    savedOrders.push(finalOrder);
    localStorage.setItem('pizzaOrders', JSON.stringify(savedOrders));

    // Simulate sending SMS
    simulateSendSms(finalOrder);

    speak(`Merci pour votre commande, ${customerName || 'Client'}. Votre numéro de commande est ${orderId}. Le total est de ${total.toFixed(2)}€. Un SMS de confirmation a été envoyé. Au revoir !`, () => {
        // End call after speaking
        handleEndCall();
    });
  };

  const simulateSendSms = (order: Order) => {
    const customerMessage = `Bonjour ${order.customerName}, votre commande (${order.id}) est confirmée: ${order.items.map(item => `${item.quantity} ${item.type} ${item.name}`).join(', ')}. Total: ${order.total.toFixed(2)}€.`;
    const restaurantMessage = `Nouvelle commande (${order.id}) pour ${order.customerName}: ${order.items.map(item => `${item.quantity} ${item.type} ${item.name}`).join(', ')}. Total: ${order.total.toFixed(2)}€.`;

    console.log("--- SMS Simulation ---");
    console.log("To Customer:", customerMessage);
    console.log("To Restaurant:", restaurantMessage);
    console.log("----------------------");

    setSmsStatus("SMS de confirmation simulés envoyés.");
  };

  const getCallStateText = () => {
    switch (callState) {
      case 'idle': return 'Inactif';
      case 'connecting': return 'Connexion...';
      case 'in-call': return 'En appel (Attente du nom)';
      case 'ordering': return 'En appel (Prise de commande)';
      case 'confirming': return 'En appel (Confirmation)';
      case 'ended': return 'Appel terminé';
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Pizza className="size-6" /> <Utensils className="size-6" /> {/* Used Utensils icon */}
          Service de Commande Vocale Pizza Bolt (Simulation)
        </CardTitle>
        <CardDescription>
          Simule une application de commande de pizza, burger, salades, lasagnes et desserts par téléphone avec interaction vocale.
          <br/>
          <Alert className="mt-4">
            <Terminal className="h-4 w-4" />
            <AlertTitle>Limitations de l'environnement WebContainer</AlertTitle>
            <AlertDescription>
              Cette application est une <strong>simulation</strong>. Elle ne peut pas gérer de vrais appels téléphoniques,
              se connecter à un serveur Ollama local, envoyer de vrais SMS, ou utiliser une base de données persistante
              en raison des restrictions du navigateur et de l'environnement. L'interaction vocale utilise les APIs natives du navigateur.
            </AlertDescription>
          </Alert>
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-col gap-4">
        <div className="flex justify-center gap-4">
          {callState === 'idle' || callState === 'ended' ? (
            <Button onClick={handleIncomingCall} className="bg-green-500 hover:bg-green-600 text-white">
              <PhoneCall className="mr-2" /> Simuler Appel Entrant
            </Button>
          ) : (
            <Button onClick={handleEndCall} variant="destructive">
              <PhoneOff className="mr-2" /> Terminer l'appel
            </Button>
          )}
        </div>

        <div className="text-center text-lg font-semibold">État de l'appel: {getCallStateText()}</div>

        {callState !== 'idle' && callState !== 'ended' && (
             <div className="flex justify-center">
                 <Button onClick={isSpeakingRef.current ? () => synthRef.current?.cancel() : startListening} variant="outline" size="icon">
                     {isSpeakingRef.current ? <MicOff className="text-red-500" /> : <Mic />}
                     <span className="sr-only">{isSpeakingRef.current ? 'Stop Speaking' : 'Start Listening'}</span>
                 </Button>
             </div>
        )}


        <ScrollArea className="h-60 border rounded-md p-4">
          <div className="flex flex-col gap-2">
            {conversation.map((msg, index) => (
              <div key={index} className={msg.startsWith('Client:') ? 'text-right text-blue-600' : 'text-left text-gray-800 dark:text-gray-200'}>
                {msg}
              </div>
            ))}
          </div>
        </ScrollArea>

        {transcript && (
          <div className="text-sm text-muted-foreground">
            Dernière transcription: <em>{transcript}</em>
          </div>
        )}

        {currentOrder.length > 0 && (
          <div>
            <h3 className="text-md font-semibold mb-2">Commande en cours pour {customerName || 'Client'}:</h3>
            <ul className="list-disc list-inside">
              {currentOrder.map((item, index) => (
                <li key={index}>
                  {item.quantity} x {item.type === 'pizza' ? 'Pizza' : item.type === 'burger' ? 'Burger' : item.type === 'salad' ? 'Salade' : item.type === 'lasagna' ? 'Lasagne' : 'Dessert'} {item.name} - {item.price.toFixed(2)}€
                  {item.specialInstructions && ` (Instructions: ${item.specialInstructions})`}
                </li>
              ))}
            </ul>
            <p className="font-bold mt-2">Total provisoire: {currentOrder.reduce((sum, item) => sum + item.price, 0).toFixed(2)}€</p>
          </div>
        )}

        {smsStatus && (
            <Alert>
                <AlertTitle>Statut SMS</AlertTitle>
                <AlertDescription>{smsStatus}</AlertDescription>
            </Alert>
        )}

        <div className="mt-4">
            <h3 className="text-lg font-semibold mb-2">Menu</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                    <h4 className="font-bold mb-2">Pizzas</h4>
                    <ul className="flex flex-col gap-3">
                        {menu.pizzas.map((pizza, index) => (
                            <li key={index} className="border rounded-md p-3">
                                <h5 className="font-semibold">{pizza.name}</h5>
                                <p className="text-sm text-muted-foreground">Garnitures: {pizza.toppings.join(', ')}</p>
                                <p className="text-sm">Prix: {Object.values(pizza.sizes)[0]?.toFixed(2)}€</p>
                            </li>
                        ))}
                    </ul>
                </div>
                 <div>
                    <h4 className="font-bold mb-2">Burgers</h4>
                    <ul className="flex flex-col gap-3">
                        {menu.burgers.map((burger, index) => (
                            <li key={index} className="border rounded-md p-3">
                                <h5 className="font-semibold">{burger.name}</h5>
                                <p className="text-sm text-muted-foreground">Garnitures: {burger.toppings.join(', ')}</p>
                                <p className="text-sm">Prix: {Object.values(burger.sizes)[0]?.toFixed(2)}€</p>
                            </li>
                        ))}
                    </ul>
                </div>
                 <div>
                    <h4 className="font-bold mb-2">Salades</h4>
                    <ul className="flex flex-col gap-3">
                        {menu.salads.map((salad, index) => (
                            <li key={index} className="border rounded-md p-3">
                                <h5 className="font-semibold">{salad.name}</h5>
                                <p className="text-sm text-muted-foreground">Ingrédients: {salad.toppings.join(', ')}</p>
                                <p className="text-sm">Prix: {Object.values(salad.sizes)[0]?.toFixed(2)}€</p>
                            </li>
                        ))}
                    </ul>
                </div>
                 <div>
                    <h4 className="font-bold mb-2">Lasagnes</h4>
                    <ul className="flex flex-col gap-3">
                        {menu.lasagna.map((lasagna, index) => (
                            <li key={index} className="border rounded-md p-3">
                                <h5 className="font-semibold">{lasagna.name}</h5>
                                <p className="text-sm text-muted-foreground">Ingrédients: {lasagna.toppings.join(', ')}</p>
                                <p className="text-sm">Prix: {Object.values(lasagna.sizes)[0]?.toFixed(2)}€</p>
                            </li>
                        ))}
                    </ul>
                </div>
                 <div>
                    <h4 className="font-bold mb-2">Desserts</h4>
                    <ul className="flex flex-col gap-3">
                        {menu.desserts.map((dessert, index) => (
                            <li key={index} className="border rounded-md p-3">
                                <h5 className="font-semibold">{dessert.name}</h5>
                                {/* Desserts might not have toppings */}
                                {dessert.toppings && dessert.toppings.length > 0 && (
                                    <p className="text-sm text-muted-foreground">Ingrédients: {dessert.toppings.join(', ')}</p>
                                )}
                                <p className="text-sm">Prix: {Object.values(dessert.sizes)[0]?.toFixed(2)}€</p>
                            </li>
                        ))}
                    </ul>
                </div>
            </div>
        </div>


        <div className="mt-4">
            <h3 className="text-lg font-semibold mb-2">Historique des Commandes (Simulation LocalStorage)</h3>
            <ScrollArea className="h-40 border rounded-md p-3">
                 {JSON.parse(localStorage.getItem('pizzaOrders') || '[]').length === 0 ? (
                     <p className="text-muted-foreground text-sm">Aucune commande enregistrée localement.</p>
                 ) : (
                    <ul className="flex flex-col gap-3">
                        {JSON.parse(localStorage.getItem('pizzaOrders') || '[]').map((order: Order) => (
                            <li key={order.id} className="border-b pb-2 last:border-b-0">
                                <p className="font-semibold">Commande {order.id} pour {order.customerName}</p>
                                <ul className="list-disc list-inside text-sm">
                                    {order.items.map((item, itemIndex) => (
                                        <li key={itemIndex}>{item.quantity} x {item.type === 'pizza' ? 'Pizza' : item.type === 'burger' ? 'Burger' : item.type === 'salad' ? 'Salade' : item.type === 'lasagna' ? 'Lasagne' : 'Dessert'} {item.name}</li>
                                    ))}
                                </ul>
                                <p className="text-sm font-bold">Total: {order.total.toFixed(2)}€</p>
                                <p className="text-xs text-muted-foreground">{new Date(order.timestamp).toLocaleString()}</p>
                            </li>
                        ))}
                    </ul>
                 )}
            </ScrollArea>
        </div>


      </CardContent>
    </Card>
  );
};

export default VoicePizzaOrder;
