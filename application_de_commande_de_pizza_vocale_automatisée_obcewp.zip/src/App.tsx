import './App.css'
import VoicePizzaOrder from './components/VoicePizzaOrder';

function App() {
  return (
    <div className="container mx-auto flex flex-col items-center justify-center min-h-screen p-4">
      <VoicePizzaOrder />
    </div>
  )
}

export default App
